import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

/**
 * Home Page - ZTech Informática
 * Neon Cyberpunk Design Theme
 * Features: Full-page responsive design with smooth scrolling
 */
export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a1628] text-white overflow-x-hidden">
      <Header />
      <main>
        <Hero />
        <Services />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
