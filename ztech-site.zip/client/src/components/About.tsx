/**
 * About Section - Neon Cyberpunk Style
 * Features: Company information, service modes, benefits
 * Design Philosophy: Professional, trustworthy, informative
 */
export default function About() {
  return (
    <section
      id="about"
      className="relative py-24 overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #000000 0%, #0a1628 100%)",
      }}
    >
      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url('https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-4_1770659859000_na1fn_Zm9vdGVyLXBhdHRlcm4.png')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* Glow Effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#0066cc] rounded-full mix-blend-screen filter blur-3xl opacity-5" />
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-[#00d4ff] rounded-full mix-blend-screen filter blur-3xl opacity-5" />

      <div className="relative z-10 container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-in fade-in slide-in-from-top-8 duration-1000">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Sobre a <span className="text-[#00d4ff]">ZTech</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Profissionais especializados em soluções de informática
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-white">
                Quem Somos
              </h3>
              <p className="text-gray-400 leading-relaxed">
                A ZTech Informática é uma empresa especializada em manutenção, formatação e suporte técnico em geral. Com profissionais experientes, oferecemos soluções confiáveis e eficientes para todos os seus problemas de informática.
              </p>
            </div>

            {/* Service Modes */}
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-white">
                Formas de Atendimento
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-4 bg-[#1a2a3a]/50 border border-[#00d4ff]/30 rounded-lg hover:border-[#00d4ff]/80 transition-colors">
                  <div className="w-3 h-3 bg-[#00d4ff] rounded-full" />
                  <span className="text-white font-medium">Atendimento Presencial</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-[#1a2a3a]/50 border border-[#00d4ff]/30 rounded-lg hover:border-[#00d4ff]/80 transition-colors">
                  <div className="w-3 h-3 bg-[#00d4ff] rounded-full" />
                  <span className="text-white font-medium">Suporte Remoto</span>
                </div>
              </div>
            </div>

            {/* Benefits */}
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-white">
                Por que nos escolher?
              </h3>
              <ul className="space-y-2">
                <li className="flex items-center gap-3 text-gray-300">
                  <svg className="w-5 h-5 text-[#00d4ff]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Profissionais especializados
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <svg className="w-5 h-5 text-[#00d4ff]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Atendimento rápido e eficiente
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <svg className="w-5 h-5 text-[#00d4ff]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Preços competitivos
                </li>
                <li className="flex items-center gap-3 text-gray-300">
                  <svg className="w-5 h-5 text-[#00d4ff]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Suporte técnico confiável
                </li>
              </ul>
            </div>
          </div>

          {/* Right Image */}
          <div className="hidden md:flex justify-center animate-in fade-in slide-in-from-right-8 duration-1000" style={{ animationDelay: "200ms" }}>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-[#00d4ff] to-[#0066cc] rounded-lg blur-2xl opacity-30 animate-pulse" />
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-2_1770659864000_na1fn_c2VydmljZXMtYmFja2dyb3VuZA.png"
                alt="ZTech Services"
                className="relative z-10 rounded-lg max-w-md w-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
