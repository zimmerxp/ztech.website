import { Check } from "lucide-react";

/**
 * Services Section - Neon Cyberpunk Style
 * Features: Grid of service cards with hover effects
 * Design Philosophy: Organized, professional, interactive
 */
const services = [
  { title: "Diagnóstico de Hardware", icon: "🔧" },
  { title: "Remoção de Vírus e Malware", icon: "🛡️" },
  { title: "Instalação de Programas e Drivers", icon: "💾" },
  { title: "Configuração de Redes e Wi-Fi", icon: "📡" },
  { title: "Backup e Recuperação de Dados", icon: "☁️" },
  { title: "Upgrade de Computadores", icon: "⚡" },
  { title: "Instalação de Softwares", icon: "📦" },
  { title: "Conserto de Notebooks", icon: "💻" },
  { title: "Conserto de Impressoras", icon: "🖨️" },
  { title: "Formatação de Computadores", icon: "🔄" },
];

export default function Services() {
  return (
    <section
      id="services"
      className="relative py-24 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #0a1628 0%, #000000 50%, #0a1628 100%)",
      }}
    >
      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url('https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-2_1770659864000_na1fn_c2VydmljZXMtYmFja2dyb3VuZA.png')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* Glow Effects */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#00d4ff] rounded-full mix-blend-screen filter blur-3xl opacity-5" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#0066cc] rounded-full mix-blend-screen filter blur-3xl opacity-5" />

      <div className="relative z-10 container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-in fade-in slide-in-from-top-8 duration-1000">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Nossos <span className="text-[#00d4ff]">Serviços</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Oferecemos uma ampla gama de serviços de informática para atender todas as suas necessidades, presencialmente ou remotamente.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className="group relative animate-in fade-in slide-in-from-bottom-8 duration-1000"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Card Background Glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#00d4ff] to-[#0066cc] rounded-lg opacity-0 group-hover:opacity-20 transition-opacity duration-300 blur" />

              {/* Card Content */}
              <div className="relative bg-[#1a2a3a]/80 backdrop-blur-sm border border-[#00d4ff]/30 group-hover:border-[#00d4ff]/80 rounded-lg p-6 transition-all duration-300 group-hover:shadow-lg group-hover:shadow-[#00d4ff]/20 group-hover:transform group-hover:scale-105">
                <div className="flex items-start gap-4">
                  <div className="text-4xl">{service.icon}</div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-[#00d4ff] transition-colors duration-300">
                      {service.title}
                    </h3>
                  </div>
                  <Check className="w-5 h-5 text-[#00d4ff] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center animate-in fade-in slide-in-from-bottom-8 duration-1000" style={{ animationDelay: "500ms" }}>
          <p className="text-gray-400 mb-6">
            Não vê seu serviço específico? Fale conosco!
          </p>
          <a
            href="https://wa.me/5531982181396?text=Olá%20ZTech!%20Gostaria%20de%20saber%20mais%20sobre%20seus%20serviços."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-[#00d4ff] text-black px-8 py-3 rounded-lg font-bold transition-all duration-300 hover:shadow-lg hover:shadow-[#00d4ff]/50 transform hover:scale-105"
          >
            Consulte-nos
          </a>
        </div>
      </div>
    </section>
  );
}
