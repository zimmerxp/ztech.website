import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";

/**
 * Header Component - Neon Cyberpunk Style
 * Fixed navigation with logo and CTA buttons
 * Features: Responsive mobile menu, WhatsApp CTA, smooth animations
 */
export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#0a1628] via-[#0a1628] to-transparent backdrop-blur-md border-b border-[#00d4ff]/20">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection("hero")}>
          <div className="text-3xl font-display text-[#00d4ff] drop-shadow-lg" style={{ textShadow: "0 0 10px #00d4ff" }}>
            Z
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold text-white font-display">TECH</span>
            <span className="text-xs text-[#00d4ff] font-display tracking-widest">INFORMÁTICA</span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <button
            onClick={() => scrollToSection("services")}
            className="text-white hover:text-[#00d4ff] transition-colors duration-300 font-medium text-sm"
          >
            Serviços
          </button>
          <button
            onClick={() => scrollToSection("about")}
            className="text-white hover:text-[#00d4ff] transition-colors duration-300 font-medium text-sm"
          >
            Sobre
          </button>
          <button
            onClick={() => scrollToSection("contact")}
            className="text-white hover:text-[#00d4ff] transition-colors duration-300 font-medium text-sm"
          >
            Contato
          </button>
        </nav>

        {/* CTA Button */}
        <div className="hidden md:flex gap-3">
          <a
            href="https://wa.me/5531982181396?text=Olá%20ZTech!%20Gostaria%20de%20saber%20mais%20sobre%20seus%20serviços."
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#25d366] hover:bg-[#20ba5a] text-white px-6 py-2 rounded-lg font-medium transition-all duration-300 flex items-center gap-2 hover:shadow-lg hover:shadow-[#25d366]/50"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.255.949c-1.238.503-2.359 1.236-3.203 2.162C3.602 9.756 3 11.309 3 12.906c0 3.864 3.278 7.006 7.593 7.006 1.346 0 2.605-.261 3.736-.72l.737-.263 3.645 1.23-.96-3.66.277-.436A7.035 7.035 0 0020.593 13c0-3.872-3.278-7.006-7.593-7.006z" />
            </svg>
            WhatsApp
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-[#00d4ff] hover:text-white transition-colors"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0a1628]/95 backdrop-blur-md border-b border-[#00d4ff]/20 animate-in fade-in slide-in-from-top-2 duration-300">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <button
              onClick={() => scrollToSection("services")}
              className="text-white hover:text-[#00d4ff] transition-colors text-left font-medium"
            >
              Serviços
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="text-white hover:text-[#00d4ff] transition-colors text-left font-medium"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-white hover:text-[#00d4ff] transition-colors text-left font-medium"
            >
              Contato
            </button>
            <a
              href="https://wa.me/5531982181396?text=Olá%20ZTech!%20Gostaria%20de%20saber%20mais%20sobre%20seus%20serviços."
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#25d366] hover:bg-[#20ba5a] text-white px-6 py-2 rounded-lg font-medium transition-all duration-300 flex items-center gap-2 justify-center"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.255.949c-1.238.503-2.359 1.236-3.203 2.162C3.602 9.756 3 11.309 3 12.906c0 3.864 3.278 7.006 7.593 7.006 1.346 0 2.605-.261 3.736-.72l.737-.263 3.645 1.23-.96-3.66.277-.436A7.035 7.035 0 0020.593 13c0-3.872-3.278-7.006-7.593-7.006z" />
              </svg>
              WhatsApp
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
