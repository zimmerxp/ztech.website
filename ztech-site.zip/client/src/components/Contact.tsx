import { Mail, Phone } from "lucide-react";
import { useState } from "react";

/**
 * Contact Section - Neon Cyberpunk Style
 * Features: Contact form, contact info, WhatsApp integration
 * Design Philosophy: Professional, accessible, conversion-focused
 */
export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Olá! Meu nome é ${formData.name}. Email: ${formData.email}. Telefone: ${formData.phone}. Mensagem: ${formData.message}`;
    const whatsappUrl = `https://wa.me/5531982181396?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
    setFormData({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <section
      id="contact"
      className="relative py-24 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #0a1628 0%, #000000 50%, #0a1628 100%)",
      }}
    >
      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url('https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-3_1770659870000_na1fn_Y29udGFjdC1zZWN0aW9uLWJn.png')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      {/* Glow Effects */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-[#25d366] rounded-full mix-blend-screen filter blur-3xl opacity-5" />
      <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-[#00d4ff] rounded-full mix-blend-screen filter blur-3xl opacity-5" />

      <div className="relative z-10 container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-in fade-in slide-in-from-top-8 duration-1000">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Entre em <span className="text-[#00d4ff]">Contato</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Resolva seus problemas de informática com um profissional especializado
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="animate-in fade-in slide-in-from-left-8 duration-1000">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-white font-medium mb-2">
                  Nome
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full bg-[#1a2a3a] border border-[#00d4ff]/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition-colors"
                  placeholder="Seu nome"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-white font-medium mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full bg-[#1a2a3a] border border-[#00d4ff]/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition-colors"
                  placeholder="seu@email.com"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-white font-medium mb-2">
                  Telefone
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-[#1a2a3a] border border-[#00d4ff]/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition-colors"
                  placeholder="(31) 98218-1396"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-white font-medium mb-2">
                  Mensagem
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={4}
                  className="w-full bg-[#1a2a3a] border border-[#00d4ff]/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition-colors resize-none"
                  placeholder="Descreva seu problema ou dúvida..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#00d4ff] text-black px-8 py-3 rounded-lg font-bold transition-all duration-300 hover:shadow-lg hover:shadow-[#00d4ff]/50 transform hover:scale-105"
              >
                Enviar via WhatsApp
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-1000" style={{ animationDelay: "200ms" }}>
            <div className="space-y-6">
              {/* WhatsApp */}
              <div className="group p-6 bg-[#1a2a3a]/50 border border-[#00d4ff]/30 rounded-lg hover:border-[#25d366]/80 transition-all duration-300 hover:shadow-lg hover:shadow-[#25d366]/20">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#25d366] rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.255.949c-1.238.503-2.359 1.236-3.203 2.162C3.602 9.756 3 11.309 3 12.906c0 3.864 3.278 7.006 7.593 7.006 1.346 0 2.605-.261 3.736-.72l.737-.263 3.645 1.23-.96-3.66.277-.436A7.035 7.035 0 0020.593 13c0-3.872-3.278-7.006-7.593-7.006z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-white font-bold mb-2">WhatsApp</h3>
                    <a
                      href="https://wa.me/5531982181396"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#25d366] hover:text-[#20ba5a] transition-colors font-medium"
                    >
                      (31) 98218-1396
                    </a>
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="group p-6 bg-[#1a2a3a]/50 border border-[#00d4ff]/30 rounded-lg hover:border-[#00d4ff]/80 transition-all duration-300 hover:shadow-lg hover:shadow-[#00d4ff]/20">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#00d4ff] rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold mb-2">Email</h3>
                    <a
                      href="mailto:ztechinformatica@hotmail.com"
                      className="text-[#00d4ff] hover:text-[#0099ff] transition-colors font-medium"
                    >
                      ztechinformatica@hotmail.com
                    </a>
                  </div>
                </div>
              </div>

              {/* Phone */}
              <div className="group p-6 bg-[#1a2a3a]/50 border border-[#00d4ff]/30 rounded-lg hover:border-[#0099ff]/80 transition-all duration-300 hover:shadow-lg hover:shadow-[#0099ff]/20">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#0099ff] rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold mb-2">Telefone</h3>
                    <a
                      href="tel:+5531982181396"
                      className="text-[#0099ff] hover:text-[#00d4ff] transition-colors font-medium"
                    >
                      (31) 98218-1396
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Info Box */}
            <div className="p-6 bg-gradient-to-r from-[#00d4ff]/10 to-[#0066cc]/10 border border-[#00d4ff]/30 rounded-lg">
              <h3 className="text-white font-bold mb-3">Horário de Atendimento</h3>
              <p className="text-gray-300 text-sm leading-relaxed">
                Atendemos presencialmente ou remotamente. Entre em contato para agendar seu atendimento ou tirar dúvidas sobre nossos serviços.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
