/**
 * Footer Component - Neon Cyberpunk Style
 * Features: Company info, quick links, social links, copyright
 * Design Philosophy: Professional, organized, accessible
 */
export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      className="relative bg-[#000000] border-t border-[#00d4ff]/20"
      style={{
        backgroundImage: `url('https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-4_1770659859000_na1fn_Zm9vdGVyLXBhdHRlcm4.png')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/80" />

      <div className="relative z-10">
        {/* Main Footer Content */}
        <div className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="text-2xl font-display text-[#00d4ff]" style={{ textShadow: "0 0 10px #00d4ff" }}>
                  Z
                </div>
                <div className="flex flex-col">
                  <span className="text-lg font-bold text-white font-display">TECH</span>
                  <span className="text-xs text-[#00d4ff] font-display tracking-widest">INFORMÁTICA</span>
                </div>
              </div>
              <p className="text-gray-400 text-sm">
                Soluções profissionais em manutenção, formatação e suporte técnico de computadores.
              </p>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="text-white font-bold">Links Rápidos</h3>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => document.getElementById("hero")?.scrollIntoView({ behavior: "smooth" })}
                    className="text-gray-400 hover:text-[#00d4ff] transition-colors text-sm"
                  >
                    Início
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
                    className="text-gray-400 hover:text-[#00d4ff] transition-colors text-sm"
                  >
                    Serviços
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
                    className="text-gray-400 hover:text-[#00d4ff] transition-colors text-sm"
                  >
                    Sobre
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
                    className="text-gray-400 hover:text-[#00d4ff] transition-colors text-sm"
                  >
                    Contato
                  </button>
                </li>
              </ul>
            </div>

            {/* Services */}
            <div className="space-y-4">
              <h3 className="text-white font-bold">Serviços</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Diagnóstico de Hardware</li>
                <li>Remoção de Vírus</li>
                <li>Formatação</li>
                <li>Suporte Remoto</li>
              </ul>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h3 className="text-white font-bold">Contato</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-gray-400">WhatsApp</p>
                  <a
                    href="https://wa.me/5531982181396"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#25d366] hover:text-[#20ba5a] transition-colors font-medium"
                  >
                    (31) 98218-1396
                  </a>
                </div>
                <div>
                  <p className="text-gray-400">Email</p>
                  <a
                    href="mailto:ztechinformatica@hotmail.com"
                    className="text-[#00d4ff] hover:text-[#0099ff] transition-colors font-medium break-all"
                  >
                    ztechinformatica@hotmail.com
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-[#00d4ff]/20 my-8" />

          {/* Bottom Footer */}
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="text-gray-500 text-sm text-center md:text-left mb-4 md:mb-0">
              &copy; {currentYear} ZTech Informática. Todos os direitos reservados.
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              <a
                href="https://wa.me/5531982181396"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-[#25d366] hover:bg-[#20ba5a] rounded-lg flex items-center justify-center transition-all duration-300 hover:shadow-lg hover:shadow-[#25d366]/50"
                title="WhatsApp"
              >
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.255.949c-1.238.503-2.359 1.236-3.203 2.162C3.602 9.756 3 11.309 3 12.906c0 3.864 3.278 7.006 7.593 7.006 1.346 0 2.605-.261 3.736-.72l.737-.263 3.645 1.23-.96-3.66.277-.436A7.035 7.035 0 0020.593 13c0-3.872-3.278-7.006-7.593-7.006z" />
                </svg>
              </a>
              <a
                href="mailto:ztechinformatica@hotmail.com"
                className="w-10 h-10 bg-[#00d4ff] hover:bg-[#0099ff] rounded-lg flex items-center justify-center transition-all duration-300 hover:shadow-lg hover:shadow-[#00d4ff]/50"
                title="Email"
              >
                <svg className="w-5 h-5 text-black" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
