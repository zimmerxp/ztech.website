/**
 * Hero Section - Neon Cyberpunk Style
 * Features: Animated background, large typography, CTA buttons
 * Design Philosophy: Bold, futuristic, eye-catching
 */
export default function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
      style={{
        background: "linear-gradient(135deg, #0a1628 0%, #000000 100%)",
      }}
    >
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Circuit Pattern Background */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url('https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-1_1770659864000_na1fn_aGVyby10ZWNoLW5lb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvajZqNlRFbDd5c3dqQ1N0VWFySDc4ay9zYW5kYm94LzJOaXE4eExIa01QRWdhakRsVjJ3bmktaW1nLTFfMTc3MDY1OTg2NDAwMF9uYTFmbl9hR1Z5YnkxMFpXTm9MVzVsYjI0LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FkufXph0-A-QlY61AZ-hOE1Qb4aTEOTLxE3eDAoOnvAd0jZrtkcs5fPzsiF4FoUIofAx6Es-KPnfFmjFplZyEzrf0za0ynYrnH~F9Co~U7SsqpxE475IX0YZ86DIAiTN6~-FNpzP-sHtEoMbwOZ8OQ~e5BOWN1igFTYaD1dtfErGRXMBcdOqMqeaQynDWUX~5B9TC3R4-ukk7VzjN8otCC5MMCUlo9MA8rIjoqAGoKdqxSCkDux9dEiQbqUX0mLxbbeGOJcWind~vvbLgpaaDFyrFRa8MXxJwEqllWSbLMqWVMsyUD~d6kWa09p3IvYr1tp96X2ZwsORFXjeYJN~NQ__')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />

        {/* Glow Effects */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00d4ff] rounded-full mix-blend-screen filter blur-3xl opacity-10 animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#0066cc] rounded-full mix-blend-screen filter blur-3xl opacity-10 animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
            <div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-4 leading-tight">
                Z<span className="text-[#00d4ff]">TECH</span>
              </h1>
              <p className="text-xl md:text-2xl text-[#00d4ff] font-display tracking-widest">
                INFORMÁTICA
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                Manutenção, Formatação,
                <br />
                <span className="text-[#00d4ff]">Suporte Técnico em Geral</span>
              </h2>
              <p className="text-lg text-gray-300">
                Atendimento presencial ou remoto
              </p>
            </div>

            <p className="text-base md:text-lg text-gray-400 max-w-md leading-relaxed">
              Entre em contato e resolva seus problemas de informática com um profissional especializado!
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a
                href="https://wa.me/5531982181396?text=Olá%20ZTech!%20Gostaria%20de%20saber%20mais%20sobre%20seus%20serviços."
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#25d366] hover:bg-[#20ba5a] text-white px-8 py-3 rounded-lg font-bold transition-all duration-300 flex items-center gap-2 justify-center hover:shadow-lg hover:shadow-[#25d366]/50 transform hover:scale-105"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.255.949c-1.238.503-2.359 1.236-3.203 2.162C3.602 9.756 3 11.309 3 12.906c0 3.864 3.278 7.006 7.593 7.006 1.346 0 2.605-.261 3.736-.72l.737-.263 3.645 1.23-.96-3.66.277-.436A7.035 7.035 0 0020.593 13c0-3.872-3.278-7.006-7.593-7.006z" />
                </svg>
                Chamar no WhatsApp
              </a>
              <button
                onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
                className="border-2 border-[#00d4ff] text-[#00d4ff] hover:bg-[#00d4ff] hover:text-black px-8 py-3 rounded-lg font-bold transition-all duration-300 transform hover:scale-105"
              >
                Saiba Mais
              </button>
            </div>
          </div>

          {/* Right Image */}
          <div className="hidden md:flex justify-center animate-in fade-in slide-in-from-right-8 duration-1000" style={{ animationDelay: "200ms" }}>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-[#00d4ff] to-[#0066cc] rounded-lg blur-2xl opacity-30 animate-pulse" />
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/j6j6TEl7yswjCStUarH78k/sandbox/2Niq8xLHkMPEgajDlV2wni-img-1_1770659864000_na1fn_aGVyby10ZWNoLW5lb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvajZqNlRFbDd5c3dqQ1N0VWFySDc4ay9zYW5kYm94LzJOaXE4eExIa01QRWdhakRsVjJ3bmktaW1nLTFfMTc3MDY1OTg2NDAwMF9uYTFmbl9hR1Z5YnkxMFpXTm9MVzVsYjI0LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FkufXph0-A-QlY61AZ-hOE1Qb4aTEOTLxE3eDAoOnvAd0jZrtkcs5fPzsiF4FoUIofAx6Es-KPnfFmjFplZyEzrf0za0ynYrnH~F9Co~U7SsqpxE475IX0YZ86DIAiTN6~-FNpzP-sHtEoMbwOZ8OQ~e5BOWN1igFTYaD1dtfErGRXMBcdOqMqeaQynDWUX~5B9TC3R4-ukk7VzjN8otCC5MMCUlo9MA8rIjoqAGoKdqxSCkDux9dEiQbqUX0mLxbbeGOJcWind~vvbLgpaaDFyrFRa8MXxJwEqllWSbLMqWVMsyUD~d6kWa09p3IvYr1tp96X2ZwsORFXjeYJN~NQ__"
                alt="ZTech Tech Support"
                className="relative z-10 rounded-lg max-w-md w-full"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-[#00d4ff]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
}
